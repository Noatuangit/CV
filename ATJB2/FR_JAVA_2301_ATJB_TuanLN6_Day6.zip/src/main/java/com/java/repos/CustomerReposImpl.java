package com.java.repos;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.SessionFactory;

import com.java.model.Customer;

@Transactional
public class CustomerReposImpl implements ICustomerRepos {
	SessionFactory sessionFactory;

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Override
	public List<Customer> findAll() {
		// TODO Auto-generated method stub
		return sessionFactory.getCurrentSession().createQuery("select c from Customer c", Customer.class)
				.getResultList();
	}

}
