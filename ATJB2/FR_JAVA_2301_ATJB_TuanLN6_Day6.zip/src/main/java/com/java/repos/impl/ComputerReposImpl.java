package com.java.repos.impl;

import com.java.model.Computer;
import com.java.repos.IComputerRepos;

import org.hibernate.SessionFactory;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;
import java.util.List;

@Repository
@Transactional
public class ComputerReposImpl implements IComputerRepos {
    private final int max_page = 4;
    private SessionFactory sessionFactory;

    public ComputerReposImpl(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    @Override
    public List<Computer> findAllByPositionAndStatus(String position, String status, Integer page) {
        String sql = "select c from Computer c where c.position like '%" + position + "%' and c.status like '%" + status + "%'";
        return sessionFactory
                .getCurrentSession()
                .createQuery(sql, Computer.class)
                .setFirstResult(page * max_page)
                .setMaxResults(max_page)
                .getResultList();
    }

    @Override
    public void save(Computer computer) {
    }

    @Override
    public long countQuery(String position, String status) {
        String sql = "select count(c) from Computer c where c.position  like '%" + position + "%' and c.status like '%" + status + "%'";
        return (long) Math.ceil(((float) ((long) sessionFactory.getCurrentSession().createQuery(sql).uniqueResult()) / max_page));
    }

    @Override
    public Integer removeById(String id) {
        try {
            sessionFactory.getCurrentSession().remove(sessionFactory.getCurrentSession().find(Computer.class, id));
            return 1;
        } catch (Exception e) {
            return 0;
        }
    }

    @Override
    public Computer findById(String id) {
        return null;
    }

    @Override
    public void edit(Computer computer) {

    }
}
