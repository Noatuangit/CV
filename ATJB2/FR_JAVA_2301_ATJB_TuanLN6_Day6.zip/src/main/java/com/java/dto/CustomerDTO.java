package com.java.dto;

import com.java.utils.EmailNotExists;
import org.hibernate.validator.constraints.NotBlank;

import javax.validation.constraints.Pattern;

public class CustomerDTO {
    @Pattern(regexp = "^[A-Za-z ÚÙỤŨỦỊỈÌỈĨÂĂÔĐÊỌÒÓÕỎÁÀẢÃẠÈÉẸẼẺƯỬỮỰỪỨỐỒỔỘỖƠỞỚỠỢẾỀỂỄỆẤẦẪẨẬẶẮẲẴẰẠÁÀẢÃúùụũủịỉìỉĩâăơởớỡợôđêọòóõỏáàảãạèéẹẽẻưửữựừứốồổộỗếềểễệấầẫẩậặắẳẵằạáàảã@#]+$",
            message = " must something and no have number!")
    String name;

    String id;

    @Pattern(regexp = "^0[0-9]{9,10}$",
            message = " must something and correct type!")
    String phone;

    @Pattern(regexp = "^[\\w\\-.]+@([\\w-]+\\.)+[\\w-]{2,4}$",
            message = " must something and correct type!")
    @EmailNotExists
    String email;

    @NotBlank
    String address;

    public CustomerDTO() {
    }

    public CustomerDTO(String id, String name, String phone, String email, String address) {
        this.id = id;
        this.name = name;
        this.phone = phone;
        this.email = email;
        this.address = address;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
}
