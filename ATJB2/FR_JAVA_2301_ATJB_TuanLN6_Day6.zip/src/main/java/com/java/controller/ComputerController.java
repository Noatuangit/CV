package com.java.controller;

import com.java.model.Computer;
import com.java.service.IComputerService;
import com.java.service.impl.ComputerServiceImpl;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/computer")
public class ComputerController {
     IComputerService computerService;

    public ComputerController(ComputerServiceImpl serviceImpl) {
        this.computerService = serviceImpl;
    }

    @GetMapping("")
    public String goHome(@RequestParam(value = "position", defaultValue = "") String position,
                         @RequestParam(value = "status", defaultValue = "") String status,
                         @RequestParam(value = "page", defaultValue = "0") Integer page,
                         Model model) {
        model.addAttribute("pageTotals", computerService.countQuery(position, status));
        model.addAttribute("position", position);
        model.addAttribute("status", status);
        model.addAttribute("page", page);
        model.addAttribute("computers", computerService.findAllByPositionAndStatus(position, status, page));
        return "computer/listComputer";
    }

    @GetMapping("delete")
    public String deleteById(Model model, @RequestParam("id") String id, RedirectAttributes redirectAttributes) {
        if (computerService.removeById(id) > 0) {
            redirectAttributes.addFlashAttribute("message", "Delete success!!!");
        }
        return "redirect:/computer";
    }

    @PostMapping()
    public String addComputer(@RequestBody Computer computer) {
        return "redirect:/computer";
    }

    @PutMapping()
    public String editComputer(@RequestBody Computer computer) {
        return "redirect:/computer";
    }
}
