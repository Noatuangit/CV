package com.java.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.java.model.Customer;
import com.java.repos.CustomerReposImpl;
import com.java.repos.ICustomerRepos;

@Service
public class CustomerServiceImpl implements ICustomerService {
	ICustomerRepos repos;

	public CustomerServiceImpl(CustomerReposImpl customerReposImpl) {
		this.repos = customerReposImpl;
	}

	@Override
	public List<Customer> findAll() {
		// TODO Auto-generated method stub
		return repos.findAll();
	}

}
