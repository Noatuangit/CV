const base_url = window.location.origin;

$(document).ready(function () {
    $("#createModal").on('hide.bs.modal', function () {
        clearValid();
        document.getElementById("form").reset();
    });
});

function deleteThis(id, position, status) {
    $('#position-delete').html(position);
    $('#status-delete').html(status);
    $('#id-delete').val(id);
}

function createComputer() {
    let id = $('#id-update').val();
    let position = $('#position-update').val();
    let status = $('#status-update').val();
    if (validateForm(position, status)) {
        let data = getDataUpdate(id, position, status);
        console.log(data)
        console.log(JSON.stringify(data))
        id !== null ? transformData("POST", data) : transformData("PUT", data);
    }
}

function getDataUpdate(id, position, status) {
    return {
        id: id,
        position: position,
        status: status
    }
}

function validateForm(position, status) {
    let flag = true;
    if ('' === position.trim()) {
        $("#required-position").css("display", "block");
        flag = false;
    }
    if ('' === status.trim()) {
        $("#required-status").css("display", "block");
        flag = false;
    }
    if (!/^[Oo][NnFf][Ff]?$|pending|waiting/.test(status) && '' !== status.trim()) {
        $("#pattern-status").css("display", "block");
        flag = false;
    }
    return flag;
}

function clearValid() {
    $("#required-status").css("display", "none");
    $("#pattern-status").css("display", "none");
    $("#required-position").css("display", "none");
}

function editForm(id, position, status) {
    $('#id-delete').val(id);
    $('#position-update').val(position);
    $('#status-update').val(status);
}

function transformData(method, data) {
    fetch(`${base_url}/api/computer`, {
        method: method,
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(data),
    })
        .then(resp => resp.json())
        .then(resp => {
        console.log((resp));
    }).catch();
}

